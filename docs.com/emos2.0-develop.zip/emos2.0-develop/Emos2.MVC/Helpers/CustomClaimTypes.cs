﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Emos2.MVC.Helpers
{
    public class CustomClaimTypes
    {
        public static readonly string AccessToken = "AccessToken";
        public static readonly string RefreshToken = "RefreshToken";
    }
}