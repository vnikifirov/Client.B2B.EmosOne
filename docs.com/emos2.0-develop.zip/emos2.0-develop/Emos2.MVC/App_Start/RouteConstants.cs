﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Emos2.MVC.App_Start
{
    public  static class RouteConstants
    {
        public static string START_CONTROLLER = "Account";

        public static string START_ACTION = "Login";

        public static string LogoutController = "Account";

        public static string LogoutAction = "Logout";


    }
}