﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Emos2.MVC.Models
{
    public class ErrorModel
    {
        public string Title { get; set; }
        public string Description { get; set; }
    }
}