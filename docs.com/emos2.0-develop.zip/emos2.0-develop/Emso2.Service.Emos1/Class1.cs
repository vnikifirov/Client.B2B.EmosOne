﻿using System;

namespace Emso2.Service.Emos1
{
    public class Class1
    {
    }
}
