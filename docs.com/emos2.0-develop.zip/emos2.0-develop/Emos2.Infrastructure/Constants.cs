﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Emos2.Infrastructure.Constants
{
    public static class Constants
    {
        public const string PostmanClientId = "PostmanClientId";
        public const string AngularClientId = "AngularClientId";
        public const string AndroidClientId = "AndroidClientId";
        public const string iOSClientId = "iOSClientId";
    }
}
